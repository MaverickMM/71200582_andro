package com.example.tugasmandiri

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity


class halaman3 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_3)

        //menerima data dari intent main activity
        val Asal = intent.getStringExtra("iniasaluser1").toString()
        val Tujuan = intent.getStringExtra("initujuanuser1").toString()
        val Tanggal = intent.getStringExtra("initgluser1").toString()
        val Jam = intent.getStringExtra("inijamuser").toString()
        val Kelas = intent.getStringExtra("inikelasuser").toString()

//tampilkan nama user
        val tvselamatdatang = findViewById<TextView>(R.id.textView4)

        tvselamatdatang.text =
            "Asal $Asal, Tujuan $Tujuan Tanggal $Tanggal  Jam $Jam Kelas $Kelas"

//ada halaman ini, terdapat rangkuman dari seluruh opsi yang diinputkan oleh pengguna beserta total
// harga tiket pesawat. Harga tiket pesawat harus berbeda, tergantung kota asal, kota tujuan, jam keberangkatan,
// dan kelas tiket.
        if (Asal == "Jakarta") {

        } else if (Asal == "Yogyakarta") {

        } else {

        }

        if (Tujuan == "Jakarta") {

        } else if (Tujuan == "Yogyakarta") {

        } else {

        }

        if (Tujuan == "Jakarta") {

        } else if (Tujuan == "Yogyakarta") {

        } else {

        }

        if (Kelas == "Bisnis") {

        } else if (Kelas == "Ekonomi") {

        } else {

        }


    }
}
