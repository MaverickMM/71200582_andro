package com.example.tugasmandiri

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class halaman2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_2)

        //menerima data dari intent main activity
        val asaluser = intent.getStringExtra("iniasaluser").toString()

        val tujuanuser = intent.getStringExtra("initujuanuser")
        val tgluser = intent.getStringExtra("initgluser").toString()

        //tampilkan nama user
//        val tvselamatdatang = findViewById<TextView>(R.id.textView2)
//
//        tvselamatdatang.text = "Selamat datang $asaluser, Password anda $tujuanuser"

        //komponen halaman login
        val tvHalamanLogin = findViewById<TextView>(R.id.tvhalamanlogin)

        //komponen edit text username
        val rghal1 = findViewById<RadioGroup>(R.id.RG_hal1)
        val rghal2 = findViewById<RadioGroup>(R.id.RG_hal2)

        val duapuluh = findViewById<RadioButton>(R.id.duapuluh)
        val enambelas = findViewById<RadioButton>(R.id.enambelas)
        val sepuluh = findViewById<RadioButton>(R.id.sepuluh)

        //komponen edit text password

        val ekonomi = findViewById<RadioButton>(R.id.ekonomi)
        val bisnis = findViewById<RadioButton>(R.id.bisnis)

        //komponen button login

        val btLogin1 = findViewById<Button>(R.id.buttonLogin1)



        //ketika button login ditekan
        btLogin1.setOnClickListener{


//            Toast.makeText(this,"Halo nama kamu: $namaUser",Toast.LENGTH_SHORT).show()


            val intent1 = Intent(this,halaman3::class.java)


            if (rghal1.checkedRadioButtonId == -1) {
                Toast.makeText(this, "Silahkan pilih salah 1 radio button", Toast.LENGTH_SHORT)
            }else if (rghal1.checkedRadioButtonId == duapuluh.id){
                intent1.putExtra("inijamuser",duapuluh.text.toString())




            }else if (rghal1.checkedRadioButtonId == enambelas.id){
                intent1.putExtra("inijamuser",enambelas.text.toString())



            }
            else if (rghal1.checkedRadioButtonId == sepuluh.id) {
                intent1.putExtra("inijamuser", sepuluh.text.toString())

            }




                if (rghal2.checkedRadioButtonId == -1) {
                    Toast.makeText(this, "Silahkan pilih salah 1 radio button", Toast.LENGTH_SHORT)
                }else if (rghal2.checkedRadioButtonId == ekonomi.id){
                    intent1.putExtra("inikelasuser",ekonomi.text.toString())




                }else if (rghal2.checkedRadioButtonId == bisnis.id){
                    intent1.putExtra("inikelasuser",bisnis.text.toString())




            }
            //memilih data user yang akan dikirimkan yaitu nama user dan passwordnya
            intent1.putExtra("iniasaluser1",asaluser.toString())
            intent1.putExtra("initujuanuser1",tujuanuser.toString())
            intent1.putExtra("initgluser1",tgluser)

            //sintax untuk berpindha halaman
            startActivity(intent1)
        }
    }
}