package com.example.tugasmandiri

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //komponen halaman login
        val tvHalamanLogin = findViewById<TextView>(R.id.tvhalamanlogin)

        //komponen edit text username
        val rgSort = findViewById<RadioGroup>(R.id.rgSort)
        val rgSort1 = findViewById<RadioGroup>(R.id.rgSort1)

        val YogAsal = findViewById<RadioButton>(R.id.yogasal)
        val JakAsal = findViewById<RadioButton>(R.id.jakartaasal)
        val BalAsal = findViewById<RadioButton>(R.id.baliasal)

        //komponen edit text password

        val YogTujuan = findViewById<RadioButton>(R.id.yogtujuan)
        val JakTujuan = findViewById<RadioButton>(R.id.jakartatujuan)
        val BalTujuan = findViewById<RadioButton>(R.id.balitujuan)

        val tgl_berangkat = findViewById<EditText>(R.id.tgl_berangkat)
        //komponen button login

        val btLogin = findViewById<Button>(R.id.buttonLogin)












        //ketika button login ditekan
        btLogin.setOnClickListener{
            val tglBerangkat = tgl_berangkat.text.toString()



//            Toast.makeText(this,"Halo nama kamu: $namaUser",Toast.LENGTH_SHORT).show()
            val intent = Intent(this,halaman2::class.java)


            if (rgSort.checkedRadioButtonId == -1) {
                Toast.makeText(this, "Silahkan pilih salah 1 radio button", Toast.LENGTH_SHORT).show()
            }else if (rgSort.checkedRadioButtonId == YogAsal.id){
                intent.putExtra("iniasaluser",YogAsal.text.toString())




            }else if (rgSort.checkedRadioButtonId == JakAsal.id){
                intent.putExtra("iniasaluser",JakAsal.text.toString())



            }
            else if (rgSort.checkedRadioButtonId == BalAsal.id) {
                intent.putExtra("iniasaluser", BalAsal.text.toString())


            }



                if (rgSort1.checkedRadioButtonId == -1) {
                    Toast.makeText(this, "Silahkan pilih salah 1 radio button", Toast.LENGTH_SHORT)
                }else if (rgSort1.checkedRadioButtonId == YogTujuan.id){
                    intent.putExtra("initujuanuser",YogTujuan.text.toString())




                }else if (rgSort1.checkedRadioButtonId == JakTujuan.id){
                    intent.putExtra("initujuanuser",JakTujuan.text.toString())



                }
                else if (rgSort1.checkedRadioButtonId == BalTujuan.id){
                    intent.putExtra("initujuanuser",BalTujuan.text.toString())



                }

                    //memilih data user yang akan dikirimkan yaitu nama user dan passwordnya
                    intent.putExtra("initgluser",tglBerangkat)
                    //sintax untuk berpindha halaman

                    startActivity(intent)
                }



            }
        }


